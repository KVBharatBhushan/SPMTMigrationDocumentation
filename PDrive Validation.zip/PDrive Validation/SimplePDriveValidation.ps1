﻿# msfs_o365admin_support
#Set-ExecutionPolicy RemoteSigned
 
# Connect with the Azure Active Directory PowerShell for Graph module
#Install-Module -Name AzureAD
#Import-Module azuread
#Get-module azuread
 
# SharePoint Online using PnP PowerShell
#Install-Module SharePointPnPPowerShellOnline -Force -SkipPublisherCheck -AllowClobber
#Import-Module SharePointPnPPowerShellOnline
 

$Admin = "Veera@abcltdnew.onmicrosoft.com"       #"VeeraBharat@XYZO365.onmicrosoft.com"
$AdminPassword = "***********"                           #"Kisan786$"
$Directory = "abcltdnew.onmicrosoft.com"                #"XYZO365.onmicrosoft.com" 
 
$CsvFilePath = "E:\CHG156539\PSDevelopmentZone\PendingUsers1.csv"
 
# Create a PowerShell connection to my directory
$SecPass = ConvertTo-SecureString $AdminPassword -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PSCredential ($Admin, $SecPass)
Connect-AzureAD -Credential $cred
#Connect-AzureAD –Credentials (Get-Credential)
 
# Import the csv file
$NewUsers = import-csv -Path $CsvFilePath
$UPNobjects = $NewUsers.'User Name'| select-object
$folderFlag = 'No'

$result = @()
 
ForEach ($UPNTemp in $UPNobjects) 
{
    $FolderPath = "E:\CHG156539\PSDevelopmentZone\Users\" + $UPNTemp  | select-object

    # FolderPath Validation
    If(Test-Path -Path $FolderPath -PathType Container)
    {
       
        $folderflag = 'Yes'
    }
    else
    {
        $folderflag = 'No'
    }

    Write-Host Username is $UPNTemp Data Restoration Status $folderflag | select-object

    $ExportItem = New-Object PSObject
    $ExportItem | Add-Member -MemberType NoteProperty -name "User" -value $UPNTemp
    $ExportItem | Add-Member -MemberType NoteProperty -name "FolderStatus" -value $folderFlag
    $result += $ExportItem
}
 
$result | Export-Csv -Path "E:\CHG156539\PSDevelopmentZone\PDriveValidationOutput.csv" -NoTypeInformation
 
 
Pause
