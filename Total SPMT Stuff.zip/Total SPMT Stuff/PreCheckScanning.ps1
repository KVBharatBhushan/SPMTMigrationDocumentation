Start-Transcript -Path "transcript.txt" -IncludeInvocationHeader

#Define SPO target#
$Global:SPOUrl = "https://XYZcorp.sharepoint.com"
$Global:UserName = "z_gvapdrivemigration@corp.XYZ.COM"
$Global:PassWord = ConvertTo-SecureString -String "#########" -AsPlainText -Force
$Global:SPOCredential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $Global:UserName, $Global:PassWord


#Import SPMT Migration Module#
Import-Module Microsoft.SharePoint.MigrationTool.PowerShell

#Register the SPMT session with SPO credentials#
Register-SPMTMigration -SPOCredential $Global:SPOCredential -ScanOnly $true -Force -SkipFilesWithExtension "pst:one:onetoc2" -WorkingFolder (Get-Item -Path ".\").FullName 

#Register the SPMT session with ScanOnly#
#Register-SPMTMigration [-ScanOnly <bool>] -Force        
        

#Login to AzureAD
Connect-AzureAD -Credential $Global:SPOCredential

#Define File Share data source#
$Global:FileshareSource = (Get-Item -Path ".\").FullName + "\Users\"
$Global:TargetSiteUrl = "https://XYZcorp-my.sharepoint.com/personal/"
$Global:UserList = @()

$csvItems = import-csv "users.csv" -Header samaccountname
ForEach ($item in $csvItems)
{
    if ($user = Get-AzureADUser -ObjectId $($item.samaccountname+"@corp.XYZ.com")) {
	    $sharesource = $Global:FileshareSource+$item.samaccountname
	    $siteurl = $Global:TargetSiteUrl+$item.samaccountname+"_corp_XYZ_com"
	    $task = (Add-SPMTTask -FileShareSource $sharesource -TargetSiteUrl $siteurl -TargetList "Documents" -TargetListRelativePath "Personal")
        $userdetails = New-Object PSObject -Property @{
            UserPrincipalName = $user.UserPrincipalName
            Mail = $user.Mail
            Guid = $task.Guid
            DisplayName = $user.DisplayName
            GivenName = $user.GivenName
        }
        $Global:UserList += $userdetails
	}
	else {
		write-output "No user found:" $($item.samaccountname+"@corp.XYZ.com")
	}
}
$migration = Get-SPMTMigration
#Start Migration in the background.#
#Start-SPMTMigration -NoShow
Start-SPMTMigration

#Cancel the started migration and unregister the migration session.#
Stop-SPMTMigration
Unregister-SPMTMigration
Disconnect-AzureAD

if ($migration.Status -eq "Finished") {
    foreach ($i in $migration.statusoftasks) {
	$Body = $null
	$BodyFailed = $null

        $user = $Global:UserList | where-object { $_.guid -eq $i.taskid}
        $Body = "<font face='Calibri'>Dear $($user.GivenName), <br><br>"
        $Body += "Please be aware that your P-drive has been successfully copied to OneDrive.<br>You may refer to <a href='https://XYZ.service-now.com/kb_view.do?sysparm_article=KB15137'>KB15137</a> to find out how to open it.<br><br>"

        if (($i.Status -eq "COMPLETED") -and ($i.MigratingProgressPercentage -ne 0)) {
            $filename = $i.reportfolder+"\ItemReport_R1.csv"
            $filelist = Import-Csv $filename
            foreach ($n in $filelist) { 
                if ($n.status -ne "Failed") {
		    # successful files are note reported
                } else {
                    $BodyFailed += $n.destination.substring($n.Destination.lastindexof("_com/Documents")+23)
                    $BodyFailed += "<br>" 
                }
            }
        }

        If ($BodyFailed) {
            $Body += "Here is the list of skipped files:<br>"
            $Body += $BodyFailed
        }

        If ($BodyFailed) { $Body += "<br><a href='https://XYZ.service-now.com/kb_view.do?sysparm_article=KB14738'>Name restrictions for files stored in OneDrive</a><br>" }
        $Body += "<br>Your P-Drive will stay in read-only mode for at least one month and then will be removed.<br><br>"
        $Body += "In case you use the library 'Business documents' it will stop working. If you want to access any of your OneDrive folder while being offline, just do the right click on it and choose 'Always keep on this device'. Read more about OneDrive <a href='https://XYZ.service-now.com/sp?id=kb_article_view&sys_kb_id=70b7055e4f6a57c40dd29dcd0310c723'>files-on-demand</a>.<br><br>"
        $Body += "For more details regarding this migration, refer to <a href='https://XYZ.service-now.com/kb_view.do?sysparm_article=KB15236'>KB15236</a> or <a href='https://XYZ.service-now.com/sp/?id=sc_cat_item&sys_id=125230584f139300bde88c401310c774'>ask GSD</a>.<br><br>"

        Send-MailMessage -To "<VeeraBharat.BhushanKaveri@XYZ.com>" -BCC "<Z_GVAPDRIVEMIGRATION@XYZ.com>", "<VeeraBharat.BhushanKaveri@XYZ.com>" -From "P-Drive migration <z_gvapdrivemigration@XYZ.COM>" -Subject "P-Drive migrated to OneDrive $(($user.userprincipalname))" -Body $Body -BodyAsHtml -Encoding Unicode -smtpserver GVASMTP
        #Send-MailMessage -To "$(($user.mail))" -BCC "<Z_GVAPDRIVEMIGRATION@XYZ.com>", "<VeeraBharat.BhushanKaveri@XYZ.com>","<Alexander.Kumzerov@XYZ.com>" -From "P-Drive migration <z_gvapdrivemigration@XYZ.COM>" -Subject "P-Drive migrated to OneDrive $(($user.userprincipalname))" -Body $Body -BodyAsHtml -Encoding Unicode -smtpserver GVASMTP
    }

    
}

Stop-Transcript
Pause
